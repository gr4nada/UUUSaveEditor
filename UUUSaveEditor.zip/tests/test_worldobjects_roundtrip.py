import json

def test_world_objects_count(sample_save):
    before = len(sample_save["worldObjects"])

    restored = json.loads(
        json.dumps(sample_save)
    )

    after = len(restored["worldObjects"])

    assert before == after