import json


def test_roundtrip_identity(sample_save):
    original = sample_save

    serialized = json.dumps(original)
    restored = json.loads(serialized)

    assert restored == original